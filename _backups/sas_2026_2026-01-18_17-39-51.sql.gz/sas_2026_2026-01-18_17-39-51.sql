/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.15-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: sas_2026
-- ------------------------------------------------------
-- Server version	10.11.15-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dbset`
--

DROP TABLE IF EXISTS `dbset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dbset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(100) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbset`
--

LOCK TABLES `dbset` WRITE;
/*!40000 ALTER TABLE `dbset` DISABLE KEYS */;
INSERT INTO `dbset` VALUES
(1,'sas_2025','2025',1),
(3,'sas_2026','2026',1);
/*!40000 ALTER TABLE `dbset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dokumenedaran`
--

DROP TABLE IF EXISTS `dokumenedaran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dokumenedaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_surat` varchar(50) NOT NULL,
  `tgl_dokumen` varchar(200) NOT NULL,
  `ditujukan` varchar(300) NOT NULL,
  `perihal` varchar(200) NOT NULL,
  `pdf` varchar(200) NOT NULL,
  `createDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dokumenedaran`
--

LOCK TABLES `dokumenedaran` WRITE;
/*!40000 ALTER TABLE `dokumenedaran` DISABLE KEYS */;
INSERT INTO `dokumenedaran` VALUES
(1,'TEST','2026-01-15','TEST','TEST','2026-1/1768461951_TEST.pdf','2026-01-15 07:25:51');
/*!40000 ALTER TABLE `dokumenedaran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dokumenkeluar`
--

DROP TABLE IF EXISTS `dokumenkeluar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dokumenkeluar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_dokumen` varchar(50) NOT NULL,
  `jns_dokumen` varchar(200) NOT NULL,
  `dari` varchar(100) NOT NULL,
  `unit_tujuan` text NOT NULL,
  `perihal` text NOT NULL,
  `pembuat` varchar(200) NOT NULL,
  `tgl_dokumen` varchar(100) NOT NULL,
  `lampiran` varchar(200) NOT NULL,
  `kategori` varchar(100) NOT NULL,
  `catatan` varchar(200) NOT NULL,
  `pdf` varchar(200) NOT NULL,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dokumenkeluar`
--

LOCK TABLES `dokumenkeluar` WRITE;
/*!40000 ALTER TABLE `dokumenkeluar` DISABLE KEYS */;
INSERT INTO `dokumenkeluar` VALUES
(1,'test','test','test','test','test','test','2026-01-18','','test','test','2026-2/1768676867_test_test.pdf','2026-01-18 02:07:47'),
(2,'test','test','test','test','test','test','2026-01-15','','test','test','2026-2027-2/1768469760_test_test.pdf','2026-01-15 16:36:00');
/*!40000 ALTER TABLE `dokumenkeluar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dokumenkeputusan`
--

DROP TABLE IF EXISTS `dokumenkeputusan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dokumenkeputusan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_surat` varchar(50) NOT NULL,
  `tgl_dokumen` varchar(200) NOT NULL,
  `ditujukan` varchar(300) NOT NULL,
  `perihal` varchar(200) NOT NULL,
  `penanggung` varchar(100) NOT NULL,
  `pdf` varchar(200) NOT NULL,
  `createDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dokumenkeputusan`
--

LOCK TABLES `dokumenkeputusan` WRITE;
/*!40000 ALTER TABLE `dokumenkeputusan` DISABLE KEYS */;
INSERT INTO `dokumenkeputusan` VALUES
(1,'TEST','2026-01-15','TEST','TEST','TEST','2026-1/1768461840_TEST.pdf','2026-01-15 07:24:00'),
(2,'test','2026-01-18','test','test','test','2026-2/1768677217_test.pdf','2026-01-17 12:13:37');
/*!40000 ALTER TABLE `dokumenkeputusan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dokumenmasuk`
--

DROP TABLE IF EXISTS `dokumenmasuk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dokumenmasuk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_dokumen` varchar(50) NOT NULL,
  `jns_dokumen` varchar(300) NOT NULL,
  `dari` varchar(100) NOT NULL,
  `perihal` varchar(200) NOT NULL,
  `lampiran` varchar(20) NOT NULL,
  `kategori` varchar(200) NOT NULL,
  `tgl_dokumen` varchar(200) NOT NULL,
  `catatan` varchar(200) NOT NULL,
  `pdf` varchar(200) NOT NULL,
  `tgl_diterima` varchar(200) NOT NULL,
  `createDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dokumenmasuk`
--

LOCK TABLES `dokumenmasuk` WRITE;
/*!40000 ALTER TABLE `dokumenmasuk` DISABLE KEYS */;
INSERT INTO `dokumenmasuk` VALUES
(2,'test','test','test','test','','test','2026-01-15','test','2026-2027-2/1768469701_test.pdf','2026-01-15','2026-01-15 09:35:01');
/*!40000 ALTER TABLE `dokumenmasuk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(50) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `attempts` int(11) NOT NULL,
  `last_attempt_time` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
INSERT INTO `login_attempts` VALUES
(40,'admin','103.154.150.21',1,'2026-01-18 17:10:40'),
(39,'admin','103.154.150.21',1,'2026-01-18 17:09:26'),
(38,'admin','103.154.150.21',1,'2026-01-18 17:09:15'),
(37,'admin','103.154.150.21',1,'2026-01-18 17:08:42'),
(36,'admin','103.154.150.21',1,'2026-01-18 17:07:01'),
(35,'admin','103.154.150.21',1,'2026-01-18 17:06:34'),
(34,'admin','103.154.150.21',1,'2026-01-18 17:06:03');
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_user`
--

DROP TABLE IF EXISTS `tb_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `level` varchar(2) NOT NULL,
  `status` varchar(2) NOT NULL,
  `poto` varchar(200) NOT NULL,
  `nik` varchar(30) NOT NULL,
  `google_auth_secret` varchar(255) DEFAULT NULL,
  `email_code` varchar(6) NOT NULL,
  `email_code_expired` datetime NOT NULL,
  `ip` varchar(200) NOT NULL,
  `last_login` varchar(200) NOT NULL,
  `idu` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`userid`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_user`
--

LOCK TABLES `tb_user` WRITE;
/*!40000 ALTER TABLE `tb_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_config`
--

DROP TABLE IF EXISTS `tbl_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_config` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `thn_dokumen` int(11) NOT NULL,
  `nm_group` varchar(25) NOT NULL,
  `status` int(11) NOT NULL,
  `CreateDate` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_config`
--

LOCK TABLES `tbl_config` WRITE;
/*!40000 ALTER TABLE `tbl_config` DISABLE KEYS */;
INSERT INTO `tbl_config` VALUES
(2,2024,'SMP171',1,'2024-11-26 23:01:45');
/*!40000 ALTER TABLE `tbl_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_jabatan`
--

DROP TABLE IF EXISTS `tbl_jabatan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_jabatan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nm_jabatan` varchar(100) NOT NULL,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_jabatan`
--

LOCK TABLES `tbl_jabatan` WRITE;
/*!40000 ALTER TABLE `tbl_jabatan` DISABLE KEYS */;
INSERT INTO `tbl_jabatan` VALUES
(1,'KEPALA SEKOLAH','2024-11-26 22:54:25'),
(2,'WAKIL KEPALA SEKOLAH BIDANG AKADEMIK','2024-11-26 22:54:37'),
(3,'WAKIL KEPALA SEKOLAH BIDANG KESISWAAN','2024-11-28 12:50:06'),
(4,'WAKIL KEPALA SEKOLAH BIDANG SARANA PRASARANA','2024-11-28 12:50:38'),
(5,'KETUA SATUAN PELAKSANA TATA USAHA','2024-11-26 22:54:59'),
(6,'TENAGA PUSTAKAWAN','2024-11-29 10:19:49'),
(7,'TENAGA KEBERSIHAN','2024-11-29 10:20:37'),
(8,'TENAGA ADMINISTRASI','2024-11-28 12:45:15'),
(9,'TENAGA KEAMANAN','2024-11-29 10:20:24'),
(10,'GURU MATA PELAJARAN IPA','2024-11-29 10:17:43'),
(11,'GURU MATA PELAJARAN IPS','2024-11-29 10:17:54'),
(12,'GURU MATA PELAJARAN MATEMATIKA','2024-11-29 10:18:04'),
(13,'GURU MATA PELAJARAN BAHASA INDONESIA','2024-11-29 10:18:25'),
(14,'GURU MATA PELAJARAN BAHASA INGGRIS','2024-11-29 10:18:38'),
(15,'GURU MATA PELAJARAN PRAKARYA','2024-11-29 10:18:54'),
(16,'GURU MATA PELAJARAN SENI BUDAYA','2024-11-29 10:19:14'),
(17,'GURU MATA PELAJARAN INFORMATIKA','2024-11-29 10:19:27'),
(18,'BENDAHARA','2025-01-10 07:14:55');
/*!40000 ALTER TABLE `tbl_jabatan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_jns_dokumen`
--

DROP TABLE IF EXISTS `tbl_jns_dokumen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_jns_dokumen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jns_dokumen` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `counter_dokumen` int(11) NOT NULL,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_jns_dokumen`
--

LOCK TABLES `tbl_jns_dokumen` WRITE;
/*!40000 ALTER TABLE `tbl_jns_dokumen` DISABLE KEYS */;
INSERT INTO `tbl_jns_dokumen` VALUES
(4,'PRESTASI SISWA','PRESTASI SISWA GROUP',1,'2024-11-26 22:56:08'),
(5,'SURAT PERMOHONAN','PERSURATAN GROUP',1,'2024-11-28 12:44:09'),
(6,'SURAT UNDANGAN','PERSURATAN GROUP',0,'2024-11-28 12:54:15'),
(7,'SURAT KETERANGAN','PERSURATAN GROUP',9,'2024-11-28 12:54:29'),
(8,'SURAT PERNYATAAN','PERSURATAN GROUP',1,'2024-11-28 12:54:52'),
(9,'PAKTA INTEGRITAS','PERSURATAN GROUP',0,'2024-11-28 12:55:04'),
(10,'PERJANJIAN (Memorandum Of Understanding)','PERSURATAN GROUP',0,'2024-11-28 13:08:01'),
(11,'SURAT KEPUTUSAN','PERSURATAN GROUP',0,'2024-11-28 13:09:17'),
(12,'SURAT TUGAS','PERSURATAN GROUP',0,'2024-11-28 13:09:35'),
(13,'SURAT PANGGILAN','PERSURATAN GROUP',0,'2024-11-29 07:08:34'),
(14,'SURAT PEMBERITAHUAN','PERSURATAN GROUP',0,'2025-01-08 07:52:22'),
(15,'SURAT IZIN','PERSURATAN GROUP',0,'2025-01-08 08:25:07'),
(16,'PERPINDAHAN PESERTA DIDIK','PERSURATAN GROUP',1,'2025-01-14 08:37:52'),
(17,'SURAT EDARAN','PERSURATAN GROUP',0,'2025-01-14 08:56:12');
/*!40000 ALTER TABLE `tbl_jns_dokumen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_kategori`
--

DROP TABLE IF EXISTS `tbl_kategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_kategori` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jns_kategori` varchar(100) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_kategori`
--

LOCK TABLES `tbl_kategori` WRITE;
/*!40000 ALTER TABLE `tbl_kategori` DISABLE KEYS */;
INSERT INTO `tbl_kategori` VALUES
(1,'BIASA','Dokumen yang bersifat surat biasa','2021-01-28 09:59:30'),
(3,'PENTING','Dokumen yang bersifat penting','2021-01-28 10:09:42'),
(4,'SEGERA','Dokumen yang bersifat sangat penting/segera','2021-01-28 10:10:02');
/*!40000 ALTER TABLE `tbl_kategori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pegawai`
--

DROP TABLE IF EXISTS `tbl_pegawai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_pegawai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nm_pegawai` varchar(100) NOT NULL,
  `nip_nikki` varchar(18) NOT NULL,
  `id_jabatan` int(11) NOT NULL,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pegawai`
--

LOCK TABLES `tbl_pegawai` WRITE;
/*!40000 ALTER TABLE `tbl_pegawai` DISABLE KEYS */;
INSERT INTO `tbl_pegawai` VALUES
(1,'SUHARTO, M.Pd','196712251998021002',1,'2024-11-28 12:48:32'),
(2,'ALI ROSIDI, M.Pd','197202212008011007',2,'2024-11-28 12:50:54'),
(3,'SUJIYATI, S.Pd','197108121997032003',3,'2024-11-28 12:51:05'),
(4,'HARIYATUN, S.Pd','197012261998032003',4,'2024-11-28 12:51:17'),
(5,'SYARIFA MASNAENI, S.Pd','198002162011012007',5,'2024-11-29 10:31:40'),
(6,'ROHMADI','1018214',8,'2024-11-29 10:40:40'),
(7,'SELVITARINA, S.Pd','1018254',8,'2024-11-29 10:40:40'),
(8,'KHAIRUL MUDASIR, S.Kom','1023648',8,'2024-11-28 11:53:05'),
(9,'MUHARRAM EKA RUHWANTO','1020713',8,'2024-11-29 11:00:12'),
(10,'MUHAMAD FARHAN SYAROFI, S.Sos','-',8,'2024-11-29 11:00:12'),
(21,'KELIK SETYOWATI','1018276',9,'2024-11-29 11:44:00'),
(22,'WASIRIN','1018277',9,'2024-11-29 11:44:22'),
(23,'JAMALUDIN','1026063',9,'2024-11-29 11:44:42'),
(24,'ARIZAL, S.T','197507042014121004',17,'2025-01-10 07:12:24'),
(25,'NUR KARTIKA CHRISTIANI, S.Pd','198106182008012018',18,'2025-01-10 07:15:45');
/*!40000 ALTER TABLE `tbl_pegawai` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_unit`
--

DROP TABLE IF EXISTS `tbl_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kd_unit` varchar(50) NOT NULL,
  `nm_unit` text NOT NULL,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1297 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_unit`
--

LOCK TABLES `tbl_unit` WRITE;
/*!40000 ALTER TABLE `tbl_unit` DISABLE KEYS */;
INSERT INTO `tbl_unit` VALUES
(1287,'SMPN 171','SMP NEGERI 171 JAKARTA GROUP','2024-11-26 22:53:38'),
(1288,'SATLAKDIKCAM','SATUAN PELAKSANA DINAS PENDIDIKAN KECAMATAN CIRACAS','2024-11-28 22:53:50'),
(1289,'DINAS','DINAS PENDIDIKAN PROVINSI DKI JAKARTA','2024-11-28 12:45:47'),
(1290,'SUKU DINAS','SUKU DINAS WILAYAH II KOTA ADMINISTRASI JAKARTA TIMUR','2024-11-28 12:46:29'),
(1291,'PESERTA DIDIK','PESERTA DIDIK SMPN 171 JAKARTA','2025-01-07 07:51:01'),
(1292,'GURU','GURU SMP NEGERI 171 JAKARTA','2025-01-07 07:51:57'),
(1293,'KARYAWAN','KARYAWAN / PEGAWAI TATA USAHA SMPN 171 JAKARTA','2025-01-07 07:53:03'),
(1294,'BKD','BADAN KEPEGAWAIAN DAERAH PROVINSI DKI JAKARTA','2025-01-14 08:58:55'),
(1295,'P4 JAKTIM','PUSAT PELATIHAN DAN PENGEMBANGAN PENDIDIKAN JAKARTA TIMUR','2025-01-14 09:04:03'),
(1296,'SEKDA','SEKRETARIAT DAERAH PROVINSI DKI JAKARTA','2025-02-10 10:56:11');
/*!40000 ALTER TABLE `tbl_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_devices`
--

DROP TABLE IF EXISTS `user_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) NOT NULL,
  `device_token` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_devices`
--

LOCK TABLES `user_devices` WRITE;
/*!40000 ALTER TABLE `user_devices` DISABLE KEYS */;
INSERT INTO `user_devices` VALUES
(15,'19','d5b73ac7d02588668bf825642ccc7e8d14b110fd8dabb6b4ac4e2949e9ba8265','2026-01-14 22:28:06','2026-02-13 15:28:06'),
(14,'19','8dd615082300c60572067ee834e177268eb4179bc3546fd135b75ba916fde931','2026-01-14 22:09:55','2026-02-13 15:09:55'),
(13,'19','da0863a3b39e1d2ead1c316ca6df1637bfafeec13506f5af44321aac085106e2','2026-01-13 01:02:39','2026-02-11 18:02:39'),
(16,'19','bd7057686b7882aed7b00aa5d603689ec71f956f14f7bdb4788398181e780974','2026-01-15 14:42:25','2026-02-14 07:42:25'),
(17,'19','efbd64e106914a9d1d4d60356553ddcc345e2536e9e758af4a8a16cfec4ea8ec','2026-01-15 16:34:12','2026-02-14 09:34:12'),
(18,'19','e828a3a907f64df18b20424c8eb2d6301b6a80aee9f6392bf756a09ea10faecf','2026-01-15 21:47:50','2026-02-14 14:47:50'),
(19,'21','5d514b11f997a6bd6264f9f6bc79976af9546a8a75ebdea7e7d4bb1ae812771f','2026-01-15 21:56:13','2026-02-14 14:56:13'),
(20,'19','1876c839bf50e5435ebb3cf8d7547074755101e95ebfe430607735563c27c2f6','2026-01-16 07:24:12','2026-02-15 00:24:12'),
(21,'19','ede7e45ff931a9b62c96c02d25ba58cbeb2a421ee3f18ede7d5d0129f264477b','2026-01-17 13:05:37','2026-02-16 06:05:37'),
(22,'21','3e9163423cb65a7b13b84a983ea0169567e2c97a8867bd196d262e3a153efd15','2026-01-17 13:07:55','2026-02-16 06:07:55'),
(23,'19','bcc6fa76676cf8f7ee5ff2f70f4f61dc72e386c1f8c83a96c8b7df828154990f','2026-01-17 13:09:16','2026-02-16 06:09:16'),
(24,'21','4b7e6d58156458f47266fd5843c6f7469d850aef24a8633a2dc5352827b14041','2026-01-17 13:10:32','2026-02-16 06:10:32');
/*!40000 ALTER TABLE `user_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_log`
--

DROP TABLE IF EXISTS `users_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(50) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `waktu` datetime NOT NULL DEFAULT current_timestamp(),
  `ip` varchar(45) NOT NULL,
  `info` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_log`
--

LOCK TABLES `users_log` WRITE;
/*!40000 ALTER TABLE `users_log` DISABLE KEYS */;
INSERT INTO `users_log` VALUES
(1,'19','Admin','2026-01-09 19:27:24','::1','Login'),
(2,'19','Admin','2026-01-09 19:29:30','::1','Login'),
(3,'19','Admin','2026-01-09 19:32:11','::1','Login'),
(4,'test','test','2026-01-09 19:43:38','::1','Login'),
(5,'18','test','2026-01-09 19:44:00','::1','Login'),
(6,'18','test','2026-01-09 19:50:56','::1','Login'),
(7,'admin','Admin','2026-01-12 17:29:43','::1','Login'),
(8,'admin','Admin','2026-01-12 18:02:39','::1','Login'),
(9,'19','Admin','2026-01-14 14:52:02','::1','Login'),
(10,'admin','Admin','2026-01-14 15:09:55','::1','Login'),
(11,'19','Admin','2026-01-14 15:12:42','::1','Login'),
(12,'admin','Admin','2026-01-14 15:28:06','::1','Login'),
(13,'19','Admin','2026-01-14 15:31:05','::1','Login'),
(14,'admin','Admin','2026-01-15 07:42:25','::1','Login'),
(15,'admin','Admin','2026-01-15 07:43:52','38.225.120.223','Login'),
(16,'1023648','KHAIRUL MUDASIR','2026-01-15 08:04:36','38.225.120.223','Login'),
(17,'19','Admin','2026-01-15 08:08:16','::1','Login'),
(18,'admin','Admin','2026-01-15 09:34:12','38.225.120.223','Login'),
(19,'19','Admin','2026-01-15 09:40:08','38.225.120.223','Login'),
(20,'19','Admin','2026-01-15 10:17:05','38.225.120.223','Login'),
(21,'admin','Admin','2026-01-15 13:16:45','114.8.213.47','Login'),
(22,'admin','Admin','2026-01-15 14:47:50','103.154.150.21','Login'),
(23,'user','user','2026-01-15 14:56:13','103.154.150.21','Login'),
(24,'admin','Admin','2026-01-15 17:13:29','103.154.150.21','Login'),
(25,'admin','Admin','2026-01-16 00:24:12','103.154.150.21','Login'),
(26,'admin','Admin','2026-01-17 06:05:37','114.8.215.63','Login'),
(27,'user','user','2026-01-17 06:07:55','114.8.215.63','Login'),
(28,'admin','Admin','2026-01-17 06:09:16','114.8.215.63','Login'),
(29,'user','user','2026-01-17 06:10:32','114.8.215.63','Login');
/*!40000 ALTER TABLE `users_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version`
--

DROP TABLE IF EXISTS `version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ver` varchar(20) NOT NULL,
  `tgl` varchar(20) NOT NULL,
  `logupdate` text NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version`
--

LOCK TABLES `version` WRITE;
/*!40000 ALTER TABLE `version` DISABLE KEYS */;
INSERT INTO `version` VALUES
(1,'1.0.1','','Initial baseline version','Starting point for update system');
/*!40000 ALTER TABLE `version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'sas_2026'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-19  0:39:51
